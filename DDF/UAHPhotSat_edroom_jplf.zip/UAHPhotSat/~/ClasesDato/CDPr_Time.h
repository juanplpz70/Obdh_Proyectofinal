#ifndef FCDPr_TimeH
#define FCDPr_TimeH
class CDPr_Time{
	
	public:
	
	protected:
	
	private:
	
};
#endif
